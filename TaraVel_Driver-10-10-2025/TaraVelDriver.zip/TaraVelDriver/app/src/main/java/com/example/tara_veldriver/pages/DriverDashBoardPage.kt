package com.example.tara_veldriver.pages

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.tara_veldriver.AuthViewModel

// Define bottom navigation items
sealed class DriverBottomNavItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    object Home : DriverBottomNavItem("driverhomepage", "Home", Icons.Filled.Home)
    object Profile : DriverBottomNavItem("driverprofilepage", "Profile", Icons.Filled.Person)
}

@Composable
fun DriverdashBoardPage(
    modifier: Modifier = Modifier,
    navController: NavHostController, // parent NavHostController
    authViewModel: AuthViewModel
) {
    val bottomNavController = rememberNavController()

    Scaffold(
        bottomBar = {
            DriverBottomNavigationBar(navController = bottomNavController)
        }
    ) { innerPadding ->
        NavHost(
            navController = bottomNavController,
            startDestination = DriverBottomNavItem.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Home Screen Composable
            composable(DriverBottomNavItem.Home.route) {
                DriverHomePage(
                    modifier = modifier,
                    navController = navController,
                    authViewModel = authViewModel
                )
            }

            // Profile Screen Composable
            composable(DriverBottomNavItem.Profile.route) {
                DriverProfilePage(
                    modifier = modifier,
                    navController = navController,
                    authViewModel = authViewModel
                )
            }
        }
    }
}

@Composable
fun DriverBottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        DriverBottomNavItem.Home,
        DriverBottomNavItem.Profile
    )

    NavigationBar {
        val currentBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = currentBackStackEntry?.destination?.route

        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
