package com.example.tara_veldriver

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import org.mindrot.jbcrypt.BCrypt

class AuthViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    fun loginUser(context: Context, username: String, password: String, onResult: (Boolean) -> Unit) {
        db.collection("accounts")
            .whereEqualTo("username", username)
            .limit(1)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val doc = documents.documents[0]
                    val rawHash = doc.getString("accessKeyHash")?.trim()

                    // Firestore stores bcrypt as "$2b$.." but jBCrypt expects "$2a$.."
                    val storedHash = rawHash?.replaceFirst("\$2b$", "\$2a$")

                    if (storedHash != null && BCrypt.checkpw(password, storedHash)) {
                        Toast.makeText(context, "✅ Login successful", Toast.LENGTH_SHORT).show()
                        onResult(true)
                    } else {
                        Toast.makeText(context, "❌ Invalid password", Toast.LENGTH_SHORT).show()
                        onResult(false)
                    }
                } else {
                    Toast.makeText(context, "❌ Invalid username", Toast.LENGTH_SHORT).show()
                    onResult(false)
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "⚠️ Error: ${e.message}", Toast.LENGTH_SHORT).show()
                onResult(false)
            }
    }

    // ✅ Function to sign out and exit the app
    fun signOut(context: Context) {
        Toast.makeText(context, "👋 Signing out...", Toast.LENGTH_SHORT).show()

        // Safely close the app by finishing all activities
        if (context is Activity) {
            context.finishAffinity()  // closes all activities
            System.exit(0)             // fully terminates the process (optional, ensures full exit)
        }
    }
}
