package com.example.tara_veldriver

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import org.mindrot.jbcrypt.BCrypt

class AuthViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    var currentUsername: String? = null
    var currentAccountId: String? = null
    var isOrgAccount: Boolean = false

    fun loginUser(
        context: Context,
        username: String,
        password: String,
        onResult: (Boolean) -> Unit
    ) {
        db.collection("accounts")
            .whereEqualTo("username", username)
            .limit(1)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val doc = documents.documents[0]
                    val rawHash = doc.getString("accessKeyHash")?.trim()
                    val storedHash = rawHash?.replaceFirst("\$2b$", "\$2a$")

                    if (storedHash != null && BCrypt.checkpw(password, storedHash)) {
                        val status = doc.getString("status") ?: "inactive"
                        if (status.lowercase() != "active") {
                            Toast.makeText(context, "🚫 Account is not active", Toast.LENGTH_SHORT).show()
                            onResult(false)
                            return@addOnSuccessListener
                        }

                        // ✅ Store logged-in account data
                        currentUsername = username
                        currentAccountId = doc.id
                        isOrgAccount = doc.contains("organizationId")

                        Toast.makeText(context, "✅ Login successful", Toast.LENGTH_SHORT).show()
                        onResult(true)
                    } else {
                        Toast.makeText(context, "❌ Invalid password", Toast.LENGTH_SHORT).show()
                        onResult(false)
                    }
                } else {
                    Toast.makeText(context, "❌ Invalid username", Toast.LENGTH_SHORT).show()
                    onResult(false)
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "⚠️ Error: ${e.message}", Toast.LENGTH_SHORT).show()
                onResult(false)
            }
    }

    fun signOut(context: Context) {
        Toast.makeText(context, "👋 Signing out...", Toast.LENGTH_SHORT).show()
        currentUsername = null
        currentAccountId = null
        isOrgAccount = false

        if (context is Activity) {
            context.finishAffinity()
            System.exit(0)
        }
    }
}
