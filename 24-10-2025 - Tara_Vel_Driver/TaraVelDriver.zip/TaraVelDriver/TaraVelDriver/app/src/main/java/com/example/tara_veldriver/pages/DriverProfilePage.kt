package com.example.tara_veldriver.pages

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter
import com.example.tara_veldriver.AuthViewModel
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun DriverProfilePage(
    modifier: Modifier = Modifier,
    navController: NavHostController,
    authViewModel: AuthViewModel
) {
    val db = FirebaseFirestore.getInstance()
    val currentAccountId = authViewModel.currentAccountId

    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var contactPerson by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var serviceType by remember { mutableStateOf("") }
    var organizationName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var vehicleName by remember { mutableStateOf("") }
    var vehicleCapacity by remember { mutableStateOf("") }
    var fairMatrixUrl by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isOrgAccount by remember { mutableStateOf(false) }
    var isImageDialogOpen by remember { mutableStateOf(false) }

    LaunchedEffect(currentAccountId) {
        if (!currentAccountId.isNullOrEmpty()) {
            db.collection("accounts").document(currentAccountId)
                .get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        displayName = doc.getString("displayName") ?: ""
                        username = doc.getString("username") ?: ""
                        status = doc.getString("status") ?: ""
                        serviceType = doc.getString("serviceType") ?: ""
                        val organizationId = doc.getString("organizationId")
                        val vehicleTypeId = doc.getString("vehicleTypeId")

                        if (!organizationId.isNullOrEmpty()) {
                            isOrgAccount = true
                            db.collection("accounts").document(organizationId)
                                .get()
                                .addOnSuccessListener { orgDoc ->
                                    if (orgDoc.exists()) {
                                        contactPerson = orgDoc.getString("contactPerson") ?: ""
                                        contactNumber = orgDoc.getString("contactNumber") ?: ""
                                        email = orgDoc.getString("email") ?: ""
                                        organizationName = orgDoc.getString("organizationName")
                                            ?: orgDoc.getString("displayName") ?: ""

                                        db.collection("images")
                                            .whereEqualTo("accountId", organizationId)
                                            .whereEqualTo("status", "active")
                                            .limit(1)
                                            .get()
                                            .addOnSuccessListener { imgQuery ->
                                                if (!imgQuery.isEmpty) {
                                                    fairMatrixUrl =
                                                        imgQuery.documents[0].getString("secureUrl")
                                                }
                                            }
                                    }
                                }
                        } else {
                            contactPerson = doc.getString("contactPerson") ?: ""
                            contactNumber = doc.getString("contactNumber") ?: ""
                            email = doc.getString("email") ?: ""

                            db.collection("images")
                                .whereEqualTo("accountId", currentAccountId)
                                .whereEqualTo("status", "active")
                                .limit(1)
                                .get()
                                .addOnSuccessListener { imgQuery ->
                                    if (!imgQuery.isEmpty) {
                                        fairMatrixUrl =
                                            imgQuery.documents[0].getString("secureUrl")
                                    }
                                }
                        }

                        if (!vehicleTypeId.isNullOrEmpty()) {
                            db.collection("vehicles").document(vehicleTypeId)
                                .get()
                                .addOnSuccessListener { vehicleDoc ->
                                    if (vehicleDoc.exists()) {
                                        vehicleName = vehicleDoc.getString("name") ?: ""
                                        vehicleCapacity =
                                            vehicleDoc.getLong("capacity")?.toString() ?: ""
                                    }
                                }
                        }
                    }
                    isLoading = false
                }
                .addOnFailureListener {
                    isLoading = false
                }
        } else {
            isLoading = false
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Account Centre",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            ProfileSection(title = "Account Information") {
                ProfileItem(label = "Display Name", value = displayName)
                ProfileItem(label = "Username", value = username)
            }

            ProfileSection(title = "Contact Information") {
                ProfileItem(label = "Contact Person", value = contactPerson)
                ProfileItem(label = "Contact Number", value = contactNumber)
                ProfileItem(label = "Email", value = email)
            }

            if (isOrgAccount) {
                ProfileSection(title = "Organization Details") {
                    ProfileItem(label = "Organization Name", value = organizationName)
                    ProfileItem(label = "Status", value = status)
                }
            } else {
                ProfileSection(title = "Service Details") {
                    ProfileItem(label = "Service Type", value = serviceType)
                    ProfileItem(label = "Status", value = status)
                }
            }

            if (vehicleName.isNotEmpty()) {
                ProfileSection(title = "Vehicle Information") {
                    ProfileItem(label = "Vehicle Name", value = vehicleName)
                    ProfileItem(label = "Capacity", value = vehicleCapacity)
                }
            }

            ProfileSection(title = "Fare Matrix") {
                if (fairMatrixUrl != null) {
                    Button(
                        onClick = { isImageDialogOpen = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("View Fare Matrix")
                    }
                } else {
                    ProfileItem(label = "Image", value = "No fare matrix uploaded")
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // ✅ UPDATED SIGN OUT BUTTON SECTION
            val context = navController.context
            val sharedPreferences =
                context.getSharedPreferences("TaraVelPrefs", Context.MODE_PRIVATE)

            OutlinedButton(
                onClick = {
                    // ✅ Clear stored login data properly
                    sharedPreferences.edit()
                        .putBoolean("isLoggedIn", false)
                        .remove("currentAccountId")
                        .remove("currentUsername")
                        .apply()

                    // ✅ Clear ViewModel session
                    authViewModel.currentAccountId = null
                    authViewModel.currentUsername = null

                    // ✅ Navigate to Login page and clear backstack
                    navController.navigate("login") {
                        popUpTo(0)
                    }

                    Toast.makeText(context, "Signed out successfully", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Sign Out")
            }
        }

        if (isImageDialogOpen && fairMatrixUrl != null) {
            Dialog(onDismissRequest = { isImageDialogOpen = false }) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { isImageDialogOpen = false },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    ) {
                        Image(
                            painter = rememberAsyncImagePainter(fairMatrixUrl),
                            contentDescription = "Fare Matrix Image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.95f)
                                .padding(4.dp),
                            contentScale = ContentScale.FillWidth
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { isImageDialogOpen = false }) {
                            Text("Close")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
    Column(content = content)
    Spacer(modifier = Modifier.height(12.dp))
}

@Composable
fun ProfileItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Medium)
        Text(text = if (value.isNotEmpty()) value else "—")
    }
}
