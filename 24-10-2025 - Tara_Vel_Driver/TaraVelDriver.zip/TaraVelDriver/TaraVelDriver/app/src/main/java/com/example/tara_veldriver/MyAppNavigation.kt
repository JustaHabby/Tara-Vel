package com.example.tara_veldriver

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.tara_veldriver.pages.*

@Composable
fun MyAppNavigation(modifier: Modifier = Modifier, authViewModel: AuthViewModel) {
    val navController = rememberNavController()
    val context = LocalContext.current

    // ✅ Read saved session
    val sharedPreferences = context.getSharedPreferences("TaraVelPrefs", Context.MODE_PRIVATE)
    val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
    val savedUsername = sharedPreferences.getString("username", null)
    val savedAccountId = sharedPreferences.getString("accountId", null)

    // ✅ Restore to ViewModel
    authViewModel.currentUsername = savedUsername
    authViewModel.currentAccountId = savedAccountId

    // ✅ Reload from Firestore if needed
    if (isLoggedIn && savedAccountId != null) {
        authViewModel.loadUserData(context) { success ->
            // Optional: you can handle failure silently
        }
    }

    val startDestination = if (isLoggedIn) "enablelocationpage" else "login"

    NavHost(navController = navController, startDestination = startDestination) {
        composable("login") {
            LoginPage(navController, authViewModel)
        }
        composable("driverdashboard") {
            DriverdashBoardPage(modifier, navController, authViewModel)
        }
        composable("driverhomepage") {
            DriverHomePage(modifier, navController, authViewModel)
        }
        composable("driverprofilepage") {
            DriverProfilePage(modifier, navController, authViewModel)
        }
        composable("forgotpasswordpage") {
            ForgotPasswordPage()
        }
        composable("enablelocationpage") {
            EnableLocationPage(modifier, navController, authViewModel)
        }
    }
}
