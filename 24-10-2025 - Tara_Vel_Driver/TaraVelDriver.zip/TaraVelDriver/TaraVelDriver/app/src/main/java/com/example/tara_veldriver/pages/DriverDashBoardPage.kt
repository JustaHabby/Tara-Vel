package com.example.tara_veldriver.pages

import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.provider.Settings
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.tara_veldriver.AuthViewModel
import kotlinx.coroutines.delay

// Define bottom navigation items
sealed class DriverBottomNavItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    object Home : DriverBottomNavItem("driverhomepage", "Home", Icons.Filled.Home)
    object Profile : DriverBottomNavItem("driverprofilepage", "Profile", Icons.Filled.Person)
}

@Composable
fun DriverdashBoardPage(
    modifier: Modifier = Modifier,
    navController: NavHostController,
    authViewModel: AuthViewModel
) {
    val bottomNavController = rememberNavController()
    val context = LocalContext.current

    // 🔍 Detect if location is turned off
    val isLocationEnabled = remember { mutableStateOf(checkIfLocationEnabled(context)) }

    // 🚨 State for showing popup dialog
    var showDialog by remember { mutableStateOf(!isLocationEnabled.value) }

    // 🔁 Auto-check location every few seconds
    LaunchedEffect(Unit) {
        while (true) {
            val enabled = checkIfLocationEnabled(context)
            if (isLocationEnabled.value != enabled) {
                isLocationEnabled.value = enabled
                showDialog = !enabled
            }
            delay(5000) // recheck every 5 seconds
        }
    }

    Scaffold(
        bottomBar = {
            DriverBottomNavigationBar(navController = bottomNavController)
        }
    ) { innerPadding ->

        // ⚠️ Show dialog if location is off
        if (showDialog) {
            AlertDialog(
                onDismissRequest = { /* Force response */ },
                title = { Text("Enable Location") },
                text = {
                    Text(
                        "Location is turned off. Please enable your location " +
                                "to continue using Tara-Vel’s features."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        // Open Location Settings
                        context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                        showDialog = false
                    }) {
                        Text("Yes")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showDialog = false
                    }) {
                        Text("No")
                    }
                }
            )
        }

        // 🧭 Navigation host
        NavHost(
            navController = bottomNavController,
            startDestination = DriverBottomNavItem.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(DriverBottomNavItem.Home.route) {
                DriverHomePage(
                    modifier = modifier,
                    navController = navController,
                    authViewModel = authViewModel
                )
            }

            composable(DriverBottomNavItem.Profile.route) {
                DriverProfilePage(
                    modifier = modifier,
                    navController = navController,
                    authViewModel = authViewModel
                )
            }
        }
    }
}

// ✅ Helper function to check if location is enabled
fun checkIfLocationEnabled(context: Context): Boolean {
    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
}

@Composable
fun DriverBottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        DriverBottomNavItem.Home,
        DriverBottomNavItem.Profile
    )

    NavigationBar {
        val currentBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = currentBackStackEntry?.destination?.route

        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
