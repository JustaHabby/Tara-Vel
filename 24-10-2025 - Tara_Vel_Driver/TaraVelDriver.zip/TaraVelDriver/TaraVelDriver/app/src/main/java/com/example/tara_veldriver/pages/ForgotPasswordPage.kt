package com.example.tara_veldriver.pages

import androidx.compose.runtime.Composable

@Composable
fun ForgotPasswordPage(){

}