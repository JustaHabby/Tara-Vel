package com.example.tara_veldriver

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.tara_veldriver.pages.LoginPage
import com.example.tara_veldriver.pages.DriverHomePage
import com.example.tara_veldriver.pages.DriverdashBoardPage
import com.example.tara_veldriver.pages.ForgotPasswordPage


@Composable
fun MyAppNavigation(modifier: Modifier = Modifier, authViewModel: AuthViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginPage(navController, authViewModel)
        }
        composable("driverdashboard") {
            DriverdashBoardPage(modifier, navController, authViewModel)
        }
        composable("driverhomepage") {
            DriverHomePage(modifier, navController, authViewModel)
        }
        composable("forgotpasswordpage") {
            ForgotPasswordPage()
        }
    }
}
