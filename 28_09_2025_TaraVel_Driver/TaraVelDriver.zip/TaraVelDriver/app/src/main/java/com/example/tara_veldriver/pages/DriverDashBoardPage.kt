package com.example.tara_veldriver.pages

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.example.tara_veldriver.AuthViewModel   // ✅ fixed import

@Composable
fun DriverdashBoardPage(
    modifier: Modifier = Modifier,
    navController: NavHostController,
    authViewModel: AuthViewModel
) {
    // Dashboard UI will go here
}
